wtforms-json
============

Adds smart json support for `WTForms`_. Useful for when using WTForms with
RESTful APIs.

.. _WTForms: https://wtforms.readthedocs.org/en/latest/


Resources
---------

- `Documentation <http://wtforms-json.readthedocs.org/>`_
- `Issue Tracker <http://github.com/kvesteri/wtforms-json/issues>`_
- `Code <http://github.com/kvesteri/wtforms-json/>`_

